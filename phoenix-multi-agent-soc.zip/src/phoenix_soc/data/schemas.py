TRIAGE_OUTPUT_SCHEMA = {
    "summary": "string",
    "severity": "low|med|high",
    "mitre_ttps": ["Txxxx"],
    "recommendations": ["string"]
}
